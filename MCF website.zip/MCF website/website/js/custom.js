/*===============================
        WATER RIPPLE EFFCDT
=================================*/
$('#home-cover').ripples({

   // The size (in pixels) of the drop that results by clicking or moving the mouse over the canvas.
    dropRadius: 15,
  
    // Basically the amount of refraction caused by a ripple. 
    // 0 means there is no refraction.
    perturbance: 0.01,
  
  });

/*=================================
            SERVICES
===================================*/
$(function () {

    // animate on scroll
    new WOW().init();
});

/*=================================
            WORK
===================================*/

$(function () {
    $("#work").magnificPopup({
        delegate: 'a', // child items selector, by clicking on it popup will open
        type: 'image',
        gallery: {
            enabled: true
        },
    });
});

/*=================================
            TEAM
===================================*/

$(function () {
    $("#team-members").owlCarousel({
        items: 3,
        autoplay: true,
        smartSpeed: 700,
        loop: true,
        autoplayHoverPause: true,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 1
            },
            // breakpoint from 480 up
            480: {
                items: 2
            },
            // breakpoint from 768 up
            768: {
                items: 3
            }
        }
    });
});

/*=================================
            TESTIMONIAL
===================================*/

$(function () {
    $("#clients-testimonials").owlCarousel({
        items: 1,
        autoplay: true,
        smartSpeed: 700,
        loop: true,
        autoplayHoverPause: true
    });
});

/*=================================
            COUNTERS
===================================*/

$(function () {
    $('.counter').counterUp({
        delay: 10,
        time: 2000
    });
});

/*=================================
            CLIENTS
===================================*/

$(function () {
    $("#clients-list").owlCarousel({
        items: 4,
        autoplay: true,
        smartSpeed: 700,
        loop: true,
        autoplayHoverPause: true,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 1
            },
            // breakpoint from 480 up
            480: {
                items: 3
            },
            // breakpoint from 768 up
            768: {
                items: 5
            },
            // breakpoint from 992 up
            992: {
                items: 6
            }
        }
    });
});



/*=================================
            NAVIGATION
===================================*/
//show/hide transparent black navigation

$(function () {
    $(window).scroll(function () {
        if ($(this).scrollTop() < 50) {
            //hide nav
            $("nav").removeClass("pt-top-nav");
            $("#back-to-top").fadeOut();
        } else {
            //show nav    
            $("nav").addClass("pt-top-nav");
            $("#back-to-top").fadeIn();
        }
    });
});

//Smooth Scrolling

$(function () {
    $("a.smooth-scroll").click(function (event) {
        event.preventDefault();
        //get/return id like #about, #work, #services and etc
        var section = $(this).attr("href");

        //add animation to the html & body element.
        $('html, body').animate({
            scrollTop: $(section).offset().top - 64
        }, 1250, "easeInOutExpo");
    });
});

//Close mobile menu on click
$(function () {
    $(".navbar-collapse ul li a").on("click touch", function () {
        $(".navbar-toggle").click();
    });
});